# Example Calculator built with TornadoFX

## Build and run the application

```bash
mvn jfx:native
java -jar target/jfx/app/calculator-1.0-jfx.jar
```

![Calculator](/screenshot.png?raw=true "Calculator")